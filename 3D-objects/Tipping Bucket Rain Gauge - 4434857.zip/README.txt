Tipping Bucket Rain Gauge by btechsol on Thingiverse: https://www.thingiverse.com/thing:4434857

Summary:
My tipping bucket rain gauge design, designed in FreeCAD.Made for use with an ESP8266 and slotted opto-switch.  All the files are included! The only part that needs supports is the bucket.Enjoy!2020-06-14 - Added a mounting bracket and filter to the mix!  There was a small update to the bucket too.  The pivot point was too low in the first version.